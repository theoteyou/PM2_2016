package aufgabenblatt3;

public class Bahnhof {

	private Zug[] zuege;
	private RangierBahnhof rangierBahnhof;
	
	public Bahnhof(){
		this(10, 10);
	}
	
	public Bahnhof(int zugAnhzal, int gleisen){
		zuege = new Zug[zugAnhzal];
		rangierBahnhof = new RangierBahnhof(gleisen);
	}
	
	public void einfahren(Zug zug, int gleis)
	{
		rangierBahnhof.zufahrtGleis(zug, gleis,true);
	}
	
	public void ausfahren( int gleis)
	{
		rangierBahnhof.zufahrtGleis(null, gleis,false);
	}
	
	
}
