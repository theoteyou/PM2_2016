package aufgabenblatt3;

public class Gleis {
	private Zug zug;

	public Gleis(){
		this(null);
	}
	
	public boolean isGleisLeer()
	{
		return zug == null;
	}
	public Gleis(Zug zug){
		this.setZug(zug);
	}

	public Zug getZug() {
		return zug;
	}

	public void setZug(Zug zug) {
		this.zug = zug;
	}
	
}
