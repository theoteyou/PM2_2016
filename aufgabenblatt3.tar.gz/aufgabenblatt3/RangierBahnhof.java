package aufgabenblatt3;

public class RangierBahnhof {

	private Gleis[] gleisen;

	public RangierBahnhof(int gleisAnzahl)
	{
		gleisen = new Gleis[gleisAnzahl];

	}

	public synchronized void zufahrtGleis(Zug zug, int gleis,boolean zufahrtRichtung){
		try{
			this.wait();
			if(zufahrtRichtung){
				if(isGleisLeer(gleis))
				{
					gleisen[gleis].setZug(zug);
				}
			}
			else{
				if(!isGleisLeer(gleis))
				{
					gleisen[gleis].setZug(zug);
				}
			}
		}
		catch(InterruptedException error)
		{
			Thread.currentThread().interrupt();
			return;
		}
		
		
		try{
			Thread.sleep(500);
			this.notifyAll();
		}
		catch(InterruptedException excep){
			
		}
		
	}
	private boolean isGleisLeer(int gleis)
	{
		return gleisen[gleis].isGleisLeer();
	}
	//	public void einfahren(Zug zug, int gleis)
	//	{
	//		if(isGleisLeer(gleis))
	//		{
	//			gleisen[gleis].setZug(zug);
	//		}
	//	}
	//	
	//	public void ausfahren( int gleis)
	//	{
	//		if(!isGleisLeer(gleis))
	//		{
	//			gleisen[gleis].setZug(null);
	//		}
	//	}

	public void clear()
	{
		for(int i = 0; i < gleisen.length; i++){
			gleisen[i].setZug(null);
		}
	}

	public boolean isFull()
	{
		for(int i = 0; i < gleisen.length; i++){
			if(gleisen[i].isGleisLeer()){
				return false;
			}
		}
		return true;
	}
}
