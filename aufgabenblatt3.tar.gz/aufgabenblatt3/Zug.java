package aufgabenblatt3;

public enum Zug {
 ICE, SBAHN, METRONOM
}
